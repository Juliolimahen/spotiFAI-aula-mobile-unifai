# spotiFAI-aula-mobile-unifai
